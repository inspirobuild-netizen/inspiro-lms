---
name: High-Density Analytics System
colors:
  surface: '#11131e'
  surface-dim: '#11131e'
  surface-bright: '#373845'
  surface-container-lowest: '#0c0e18'
  surface-container-low: '#191b26'
  surface-container: '#1d1f2b'
  surface-container-high: '#272935'
  surface-container-highest: '#323440'
  on-surface: '#e1e1f2'
  on-surface-variant: '#ccc3d8'
  inverse-surface: '#e1e1f2'
  inverse-on-surface: '#2e303c'
  outline: '#958da1'
  outline-variant: '#4a4455'
  surface-tint: '#d2bbff'
  primary: '#d2bbff'
  on-primary: '#3f008e'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#732ee4'
  secondary: '#4fdbc8'
  on-secondary: '#003731'
  secondary-container: '#04b4a2'
  on-secondary-container: '#003f38'
  tertiary: '#ffb2b7'
  on-tertiary: '#67001b'
  tertiary-container: '#c81a42'
  on-tertiary-container: '#ffdedf'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#11131e'
  on-background: '#e1e1f2'
  surface-variant: '#323440'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-width: 260px
  container-max-width: 1440px
  gutter: 24px
  margin: 32px
  unit: 4px
---

## Brand & Style

This design system is engineered for high-performance data management and deep analytical workflows. It prioritizes information density and technical precision while maintaining a futuristic, high-energy aesthetic. The visual narrative combines **Minimalism** with subtle **Glassmorphism** to create a multi-layered workspace that feels both expansive and organized.

The brand personality is authoritative, innovative, and focused. It targets power users—analysts, engineers, and managers—who require a UI that stays out of the way of the data while providing clear visual cues for status and performance. The interaction model is snappy and precise, evoking a sense of "command and control" through dark-mode surfaces and neon-tinted accents.

## Colors

The palette is anchored by the signature **Deep Violet** (#7C3AED) as the primary brand driver, used for key actions and active states. **Electric Teal** (#14B8A6) serves as the secondary color, primarily for success states, growth indicators, and data visualizations. A tertiary **Punchy Rose** (#F43F5E) is reserved for destructive actions and critical alerts.

The background uses a deep, ink-like **#0D0F1A**, providing a high-contrast canvas for the vibrant primary accents. Surfaces and containers use layered shades of navy and charcoal to create depth without relying on heavy shadows. Neutral tones are cool-skewed to maintain the technical, "pro-tool" atmosphere.

## Typography

The system utilizes **Geist** for headlines and body copy to ensure a clean, technical, and highly legible appearance on high-resolution displays. Its geometric yet neutral construction allows for high information density without visual clutter.

For data-specific contexts—such as table cells, chart axes, and status indicators—**JetBrains Mono** is employed. This monospaced choice ensures that numerical values align perfectly, aiding in the rapid scanning of analytics and financial figures. Weight is used strategically to indicate hierarchy; bold weights are reserved for high-level metrics, while regular weights handle the bulk of management interfaces.

## Layout & Spacing

The layout utilizes a **12-column fixed grid** (max-width 1440px) centered within the viewport. A persistent **260px sidebar** sits on the left, housing primary navigation and workspace switching. The main content area is designed for high-density viewing, utilizing a 4px baseline grid for fine-grained control over component internal spacing.

- **Desktop (1280px+):** 12 columns, 24px gutters, 32px outer margins.
- **Tablet (768px - 1279px):** Sidebar collapses to icons only (64px). 8 columns, 16px gutters.
- **Mobile (<767px):** Sidebar hidden (accessed via hamburger). 4 columns, 12px gutters.

Spacing follows a strict power-of-two scale (4, 8, 16, 24, 32, 48, 64) to maintain rhythmic consistency across dense data views.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Glassmorphism**. Rather than traditional drop shadows, depth is communicated through brightness:
- **Level 0 (Background):** #0D0F1A.
- **Level 1 (Main Content Cards):** #161B2B with a 1px solid border (#2D3348).
- **Level 2 (Popovers/Modals):** #1C2237 with a subtle backdrop blur (12px) and a slightly brighter border.

Active states on buttons and selected sidebar items use a soft outer glow (bloom) in the Primary Deep Violet color to simulate a light-emitting interface. Charts and data widgets use semi-transparent fills to allow the background texture to peek through, creating a sophisticated, multi-dimensional aesthetic.

## Shapes

The design system uses a **Soft** (Level 1) shape language. This provides 0.25rem (4px) corner radii for standard elements like input fields, buttons, and small cards. Larger containers, such as main dashboard widgets, use `rounded-lg` (8px). 

This low-radius approach maintains a professional, "engineered" feel that maximizes screen real estate, as sharper corners feel more aligned with the rigid structure of data tables and charts than highly rounded or pill-shaped forms.

## Components

### Navigation & Sidebar
The sidebar uses low-contrast labels that shift to High-Contrast White and Primary Violet icons on hover/active states. Group headers are in `label-sm` all-caps.

### Data Tables
Tables are high-density. Row height is fixed at 40px. Headers use `label-md` with a subtle bottom border. Zebra striping is avoided; instead, use 1px horizontal dividers (#2D3348). Column types (currency, date, status) must follow specific alignment rules: numbers right-aligned, text left-aligned.

### Buttons
- **Primary:** Solid Deep Violet with white text. Subtle 8px glow on hover.
- **Secondary:** Ghost style with Electric Teal border and text.
- **Tertiary:** Transparent background with neutral-grey text, shifting to white on hover.

### Analytics Widgets
- **Line Charts:** Use 2px stroke width with Electric Teal. Fills should be a gradient of the stroke color to transparent (15% opacity max).
- **Status Indicators:** Use 8px solid dots. Teal for "Operational," Violet for "Processing," and Rose for "Critical."
- **Input Fields:** Darker background (#090B14) with a 1px border. Focus state triggers a Primary Violet border and a 2px outer glow.

### Cards
Cards are the primary container for analytics. They must include a `headline-md` title and a `label-sm` metadata line. Padding is fixed at 24px for all inner content.